const SYSTEM = document.createElement('div');
SYSTEM.id = 'SYSTEM';
document.body.appendChild(SYSTEM);
